package com.example.logonrmlocal.questao_um;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void doPesquisar(View view){

        EditText edtId = findViewById(R.id.edtId);
        TextView txtTitle = findViewById(R.id.txtTitle);
        TextView txtCompleted = findViewById(R.id.txtCompleted);

        String url = "https://jsonplaceholder.typicode.com/todos/" + edtId.getText().toString();

        new DataGetter(txtTitle,txtCompleted).execute(url);

        edtId.selectAll();


    }
}
